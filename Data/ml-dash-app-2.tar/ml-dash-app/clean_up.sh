rm Data/Output/*.pkl
rm Data/Output/Metrics/*
